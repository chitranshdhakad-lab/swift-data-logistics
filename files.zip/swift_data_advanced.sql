-- =====================================================
-- Swift Data : View, Trigger, Stored Procedure (Transaction)
-- Run in MySQL Workbench. DELIMITER lines are needed for triggers/procedures.
-- =====================================================
USE swift_data;

-- 1. VIEW: live status of every shipment with its latest event ----------
CREATE OR REPLACE VIEW v_live_shipment_status AS
SELECT s.tracking_number,
       cs.name  AS sender,
       cr.name  AS receiver,
       hs.city  AS from_city,
       hd.city  AS to_city,
       s.current_status,
       s.expected_date,
       le.status     AS last_event,
       le.event_time AS last_event_time
FROM Shipment s
JOIN Customer cs ON cs.customer_id = s.sender_id
JOIN Customer cr ON cr.customer_id = s.receiver_id
JOIN Hub hs ON hs.hub_id = s.source_hub_id
JOIN Hub hd ON hd.hub_id = s.dest_hub_id
LEFT JOIN Tracking_Event le
       ON le.event_id = (SELECT e.event_id FROM Tracking_Event e
                         WHERE e.shipment_id = s.shipment_id
                         ORDER BY e.event_time DESC, e.event_id DESC LIMIT 1);

-- 2. TRIGGER: a new tracking event keeps Shipment.current_status in sync --
DROP TRIGGER IF EXISTS trg_event_updates_shipment;
DELIMITER $$
CREATE TRIGGER trg_event_updates_shipment
AFTER INSERT ON Tracking_Event
FOR EACH ROW
BEGIN
    UPDATE Shipment
    SET current_status = CASE NEW.status
            WHEN 'Booked'           THEN 'Booked'
            WHEN 'Out for Delivery' THEN 'Out for Delivery'
            WHEN 'Delivered'        THEN 'Delivered'
            WHEN 'Failed'           THEN 'Failed'
            ELSE 'In Transit'
        END,
        delivered_date = IF(NEW.status = 'Delivered', NEW.event_time, delivered_date)
    WHERE shipment_id = NEW.shipment_id;
END$$
DELIMITER ;

-- 3. STORED PROCEDURE with a TRANSACTION (ACID demo) ----------------------
-- Loads a shipment onto a trip: all three steps succeed together or none do.
DROP PROCEDURE IF EXISTS sp_assign_shipment_to_trip;
DELIMITER $$
CREATE PROCEDURE sp_assign_shipment_to_trip(IN p_trip_id INT, IN p_shipment_id INT)
BEGIN
    DECLARE v_vehicle INT;
    DECLARE v_weight DECIMAL(8,2);
    DECLARE v_load DECIMAL(8,2);
    DECLARE v_cap DECIMAL(8,2);
    DECLARE v_from INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT vehicle_id, from_hub_id INTO v_vehicle, v_from
    FROM Trip WHERE trip_id = p_trip_id AND status IN ('Planned','Ongoing')
    FOR UPDATE;
    IF v_vehicle IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Trip not found or not open for loading';
    END IF;

    SELECT weight_kg INTO v_weight FROM Shipment WHERE shipment_id = p_shipment_id FOR UPDATE;
    IF v_weight IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Shipment not found';
    END IF;

    SELECT current_load_kg, capacity_kg INTO v_load, v_cap
    FROM Vehicle WHERE vehicle_id = v_vehicle FOR UPDATE;
    IF v_load + v_weight > v_cap THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Vehicle capacity exceeded';
    END IF;

    INSERT INTO Trip_Shipment (trip_id, shipment_id) VALUES (p_trip_id, p_shipment_id);
    UPDATE Vehicle SET current_load_kg = current_load_kg + v_weight WHERE vehicle_id = v_vehicle;
    INSERT INTO Tracking_Event (shipment_id, hub_id, status, remarks)
    VALUES (p_shipment_id, v_from, 'Departed Hub', CONCAT('Loaded on trip ', p_trip_id));

    COMMIT;
END$$
DELIMITER ;

-- ---------------- DEMO / TESTS ----------------
-- View
SELECT * FROM v_live_shipment_status;

-- Trigger demo: add an event and watch Shipment.current_status change
INSERT INTO Tracking_Event (shipment_id, hub_id, status, remarks)
VALUES (11, 5, 'Delivered', 'Signed by receiver');
SELECT tracking_number, current_status, delivered_date FROM Shipment WHERE shipment_id = 11;

-- Transaction demo 1 (should succeed): new trip, load shipment 12 (2 kg)
INSERT INTO Trip (driver_id, vehicle_id, from_hub_id, to_hub_id, start_time, status)
VALUES (7, 7, 5, 2, NOW(), 'Planned');
CALL sp_assign_shipment_to_trip(LAST_INSERT_ID(), 12);
SELECT plate_no, current_load_kg FROM Vehicle WHERE vehicle_id = 7;

-- Transaction demo 2 (second call should FAIL and roll back):
-- a bike holds 25 kg. Shipment 6 (20 kg) fits, then shipment 10 (9 kg) would make 29 kg.
INSERT INTO Trip (driver_id, vehicle_id, from_hub_id, to_hub_id, start_time, status)
VALUES (2, 2, 2, 1, NOW(), 'Planned');
SET @bike_trip = LAST_INSERT_ID();
CALL sp_assign_shipment_to_trip(@bike_trip, 6);    -- OK, load becomes 20 kg
CALL sp_assign_shipment_to_trip(@bike_trip, 10);   -- expect: Vehicle capacity exceeded
SELECT plate_no, current_load_kg FROM Vehicle WHERE vehicle_id = 2;  -- still 20, nothing half-saved
