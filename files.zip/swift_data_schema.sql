-- =====================================================
-- Swift Data : Delivery Logistics DBMS (MySQL 8+)
-- Step 1: Schema (tables + constraints + indexes)
-- =====================================================

DROP DATABASE IF EXISTS swift_data;
CREATE DATABASE swift_data;
USE swift_data;

-- 1. CUSTOMER -----------------------------------------
CREATE TABLE Customer (
    customer_id   INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    phone         VARCHAR(15)  NOT NULL UNIQUE,
    email         VARCHAR(100) UNIQUE,
    address       VARCHAR(255) NOT NULL,
    city          VARCHAR(50)  NOT NULL,
    pincode       CHAR(6)      NOT NULL
);

-- 2. HUB ----------------------------------------------
CREATE TABLE Hub (
    hub_id    INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100) NOT NULL,
    city      VARCHAR(50)  NOT NULL,
    capacity  INT NOT NULL,
    CONSTRAINT chk_hub_capacity CHECK (capacity > 0)
);

-- 3. DRIVER -------------------------------------------
CREATE TABLE Driver (
    driver_id   INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    phone       VARCHAR(15)  NOT NULL UNIQUE,
    license_no  VARCHAR(20)  NOT NULL UNIQUE,
    hub_id      INT NOT NULL,
    status      ENUM('Active','On Leave','Inactive') NOT NULL DEFAULT 'Active',
    FOREIGN KEY (hub_id) REFERENCES Hub(hub_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- 4. VEHICLE ------------------------------------------
CREATE TABLE Vehicle (
    vehicle_id    INT AUTO_INCREMENT PRIMARY KEY,
    plate_no      VARCHAR(15) NOT NULL UNIQUE,
    type          ENUM('Bike','Van','Truck') NOT NULL,
    capacity_kg   DECIMAL(8,2) NOT NULL,
    current_load_kg DECIMAL(8,2) NOT NULL DEFAULT 0,
    hub_id        INT NOT NULL,
    status        ENUM('Available','On Trip','Maintenance') NOT NULL DEFAULT 'Available',
    CONSTRAINT chk_vehicle_cap  CHECK (capacity_kg > 0),
    CONSTRAINT chk_vehicle_load CHECK (current_load_kg >= 0 AND current_load_kg <= capacity_kg),
    FOREIGN KEY (hub_id) REFERENCES Hub(hub_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
);

-- 5. SHIPMENT (Order + Package merged) ----------------
CREATE TABLE Shipment (
    shipment_id      INT AUTO_INCREMENT PRIMARY KEY,
    tracking_number  VARCHAR(20) NOT NULL UNIQUE,
    sender_id        INT NOT NULL,
    receiver_id      INT NOT NULL,
    source_hub_id    INT NOT NULL,
    dest_hub_id      INT NOT NULL,
    weight_kg        DECIMAL(8,2) NOT NULL,
    is_fragile       BOOLEAN NOT NULL DEFAULT FALSE,
    service_type     ENUM('Standard','Express') NOT NULL DEFAULT 'Standard',
    booking_date     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expected_date    DATE NOT NULL,
    delivered_date   DATETIME NULL,
    current_status   ENUM('Booked','In Transit','Out for Delivery','Delivered','Failed')
                     NOT NULL DEFAULT 'Booked',
    cost             DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_ship_weight CHECK (weight_kg > 0),
    CONSTRAINT chk_ship_cost   CHECK (cost >= 0),
    CONSTRAINT chk_ship_parties CHECK (sender_id <> receiver_id),
    FOREIGN KEY (sender_id)     REFERENCES Customer(customer_id),
    FOREIGN KEY (receiver_id)   REFERENCES Customer(customer_id),
    FOREIGN KEY (source_hub_id) REFERENCES Hub(hub_id),
    FOREIGN KEY (dest_hub_id)   REFERENCES Hub(hub_id)
);

-- 6. TRIP ---------------------------------------------
CREATE TABLE Trip (
    trip_id        INT AUTO_INCREMENT PRIMARY KEY,
    driver_id      INT NOT NULL,
    vehicle_id     INT NOT NULL,
    from_hub_id    INT NOT NULL,
    to_hub_id      INT NOT NULL,
    start_time     DATETIME NOT NULL,
    end_time       DATETIME NULL,
    status         ENUM('Planned','Ongoing','Completed','Cancelled') NOT NULL DEFAULT 'Planned',
    CONSTRAINT chk_trip_time CHECK (end_time IS NULL OR end_time > start_time),
    FOREIGN KEY (driver_id)   REFERENCES Driver(driver_id),
    FOREIGN KEY (vehicle_id)  REFERENCES Vehicle(vehicle_id),
    FOREIGN KEY (from_hub_id) REFERENCES Hub(hub_id),
    FOREIGN KEY (to_hub_id)   REFERENCES Hub(hub_id)
);

-- 7. TRIP_SHIPMENT (junction for M:N) -----------------
CREATE TABLE Trip_Shipment (
    trip_id      INT NOT NULL,
    shipment_id  INT NOT NULL,
    loaded_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (trip_id, shipment_id),
    FOREIGN KEY (trip_id)     REFERENCES Trip(trip_id)         ON DELETE CASCADE,
    FOREIGN KEY (shipment_id) REFERENCES Shipment(shipment_id) ON DELETE CASCADE
);

-- 8. TRACKING_EVENT -----------------------------------
CREATE TABLE Tracking_Event (
    event_id     INT AUTO_INCREMENT PRIMARY KEY,
    shipment_id  INT NOT NULL,
    hub_id       INT NULL,
    status       ENUM('Booked','Picked Up','Arrived at Hub','Departed Hub',
                      'Out for Delivery','Delivered','Failed') NOT NULL,
    remarks      VARCHAR(255),
    event_time   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (shipment_id) REFERENCES Shipment(shipment_id) ON DELETE CASCADE,
    FOREIGN KEY (hub_id)      REFERENCES Hub(hub_id) ON DELETE SET NULL
);

-- INDEXES (speed up the most common lookups) ----------
CREATE INDEX idx_event_shipment_time ON Tracking_Event (shipment_id, event_time);
CREATE INDEX idx_shipment_status     ON Shipment (current_status);
CREATE INDEX idx_trip_driver         ON Trip (driver_id, start_time);
