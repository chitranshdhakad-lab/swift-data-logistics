-- =====================================================
-- Swift Data : Sample data (run AFTER swift_data_schema.sql)
-- =====================================================
USE swift_data;

INSERT INTO Hub (name, city, capacity) VALUES
('Bhopal Central Hub',  'Bhopal', 5000),
('Indore Sorting Hub',  'Indore', 4000),
('Delhi Gateway Hub',   'Delhi',  9000),
('Mumbai Port Hub',     'Mumbai', 8000),
('Nagpur Zero Mile Hub','Nagpur', 3500);

INSERT INTO Customer (name, phone, email, address, city, pincode) VALUES
('Aarav Sharma',  '9810000001', 'aarav@mail.com',  '12 MP Nagar',        'Bhopal', '462011'),
('Priya Verma',   '9810000002', 'priya@mail.com',  '45 Vijay Nagar',     'Indore', '452010'),
('Rohit Mehta',   '9810000003', 'rohit@mail.com',  '7 Arera Colony',     'Bhopal', '462016'),
('Sneha Kapoor',  '9810000004', 'sneha@mail.com',  '22 Karol Bagh',      'Delhi',  '110005'),
('Vikram Singh',  '9810000005', 'vikram@mail.com', '3 Palasia',          'Indore', '452001'),
('Ananya Iyer',   '9810000006', 'ananya@mail.com', '88 Andheri West',    'Mumbai', '400053'),
('Karan Malhotra','9810000007', 'karan@mail.com',  '15 Dwarka Sec 10',   'Delhi',  '110075'),
('Neha Gupta',    '9810000008', 'neha@mail.com',   '9 Kolar Road',       'Bhopal', '462042'),
('Rahul Desai',   '9810000009', 'rahul@mail.com',  '31 Bandra East',     'Mumbai', '400051'),
('Pooja Joshi',   '9810000010', 'pooja@mail.com',  '64 Dharampeth',      'Nagpur', '440010'),
('Amit Patil',    '9810000011', 'amit@mail.com',   '18 Sitabuldi',       'Nagpur', '440012'),
('Kavita Rao',    '9810000012', 'kavita@mail.com', '5 Shahpura',         'Bhopal', '462016');

INSERT INTO Driver (name, phone, license_no, hub_id, status) VALUES
('Ramesh Yadav',  '9900000001', 'MP0420200001', 1, 'Active'),
('Suresh Patel',  '9900000002', 'MP0920200002', 2, 'Active'),
('Mahesh Kumar',  '9900000003', 'MP0420200003', 1, 'Active'),
('Dinesh Chouhan','9900000004', 'MP0920200004', 2, 'Active'),
('Imran Khan',    '9900000005', 'DL0120200005', 3, 'Active'),
('Sanjay Pawar',  '9900000006', 'MH0120200006', 4, 'Active'),
('Prakash Bhoyar','9900000007', 'MH3120200007', 5, 'Active'),
('Gurpreet Singh','9900000008', 'DL0120200008', 3, 'On Leave');

INSERT INTO Vehicle (plate_no, type, capacity_kg, current_load_kg, hub_id, status) VALUES
('MP04AB1001','Van',   800,  0, 1,'Available'),
('MP09CD2002','Bike',   25,  0, 2,'Available'),
('MP04EF3003','Truck',5000,  0, 1,'Available'),
('MP09GH4004','Van',   900, 15, 2,'On Trip'),
('DL01JK5005','Truck',4000,  0, 3,'Available'),
('MH01LM6006','Van',  1000,  9, 4,'On Trip'),
('MH31NP7007','Van',   700,  0, 5,'Available'),
('DL01QR8008','Bike',   30,  0, 3,'Maintenance');

INSERT INTO Shipment (tracking_number, sender_id, receiver_id, source_hub_id, dest_hub_id,
                      weight_kg, is_fragile, service_type, booking_date, expected_date,
                      delivered_date, current_status, cost) VALUES
('TRK1001', 1, 2, 1, 2,  2.50, FALSE,'Standard','2026-09-01 10:00','2026-09-04','2026-09-03 12:15','Delivered',150),
('TRK1002', 3, 4, 1, 3,  5.00, FALSE,'Express', '2026-09-02 11:00','2026-09-04','2026-09-05 11:30','Delivered',600),
('TRK1003', 5, 6, 2, 4, 12.00, FALSE,'Standard','2026-09-03 09:00','2026-09-07','2026-09-06 13:00','Delivered',400),
('TRK1004', 7, 8, 3, 1,  1.20, TRUE, 'Express', '2026-09-05 12:00','2026-09-07','2026-09-07 11:00','Delivered',350),
('TRK1005', 2, 1, 2, 1,  8.00, FALSE,'Standard','2026-09-06 15:00','2026-09-10','2026-09-12 10:45','Delivered',220),
('TRK1006', 9,10, 4, 5, 20.00, FALSE,'Standard','2026-09-08 10:00','2026-09-13','2026-09-13 11:30','Delivered',550),
('TRK1007',11,12, 5, 1,  3.00, FALSE,'Express', '2026-09-10 10:00','2026-09-12',NULL,               'Failed',   300),
('TRK1008', 4, 5, 3, 2,  6.50, FALSE,'Standard','2026-09-12 09:00','2026-09-17','2026-09-18 12:00','Delivered',380),
('TRK1009', 1, 6, 1, 4, 15.00, TRUE, 'Express', '2026-09-15 10:00','2026-09-18',NULL,               'In Transit',700),
('TRK1010', 6, 7, 4, 3,  9.00, FALSE,'Standard','2026-09-18 10:00','2026-09-23',NULL,               'In Transit',450),
('TRK1011', 4,10, 3, 5,  4.00, FALSE,'Standard','2026-09-20 10:00','2026-09-25',NULL,               'Out for Delivery',420),
('TRK1012',11, 2, 5, 2,  2.00, FALSE,'Express', '2026-09-22 10:00','2026-09-24',NULL,               'Booked',   280),
('TRK1013',12, 7, 1, 3,  7.00, FALSE,'Standard','2026-09-25 10:00','2026-09-30',NULL,               'Booked',   390),
('TRK1014', 3,11, 1, 5, 11.00, FALSE,'Standard','2026-09-26 10:00','2026-10-01',NULL,               'Failed',   480),
('TRK1015', 5, 1, 2, 1,  3.50, FALSE,'Express', '2026-09-28 10:00','2026-09-30','2026-09-30 11:00','Delivered',260);

INSERT INTO Trip (driver_id, vehicle_id, from_hub_id, to_hub_id, start_time, end_time, status) VALUES
(1,1,1,2,'2026-09-02 10:00','2026-09-02 14:30','Completed'),  -- 1
(3,3,1,3,'2026-09-03 09:00','2026-09-05 08:00','Completed'),  -- 2
(4,4,2,4,'2026-09-04 09:00','2026-09-05 20:00','Completed'),  -- 3
(5,5,3,1,'2026-09-06 08:00','2026-09-07 05:00','Completed'),  -- 4
(2,2,2,1,'2026-09-11 09:00','2026-09-11 19:00','Completed'),  -- 5
(6,6,4,5,'2026-09-09 08:00','2026-09-12 18:00','Completed'),  -- 6
(1,1,1,2,'2026-09-16 09:00','2026-09-16 14:00','Completed'),  -- 7
(6,6,4,3,'2026-09-19 09:00',NULL,                'Ongoing'),    -- 8
(5,5,3,2,'2026-09-14 09:00','2026-09-17 20:00','Completed'),  -- 9
(7,7,1,5,'2026-09-27 09:00','2026-09-30 18:00','Completed'),  -- 10
(4,4,2,4,'2026-09-17 06:00',NULL,                'Ongoing'),    -- 11
(5,5,3,5,'2026-09-21 09:00','2026-09-24 18:00','Completed'),  -- 12
(7,7,5,1,'2026-09-11 10:00','2026-09-12 02:00','Completed'),  -- 13
(3,1,2,1,'2026-09-29 09:00','2026-09-29 15:00','Completed');  -- 14

-- Shipment 9 rides two trips (7 then 11): the M:N relationship
INSERT INTO Trip_Shipment (trip_id, shipment_id, loaded_at) VALUES
(1,1,'2026-09-02 09:45'),(2,2,'2026-09-03 08:45'),(3,3,'2026-09-04 08:45'),
(4,4,'2026-09-06 07:45'),(5,5,'2026-09-11 08:45'),(6,6,'2026-09-09 07:45'),
(7,9,'2026-09-16 08:45'),(8,10,'2026-09-19 08:45'),(9,8,'2026-09-14 08:45'),
(10,14,'2026-09-27 08:45'),(11,9,'2026-09-17 05:45'),(12,11,'2026-09-21 08:45'),
(13,7,'2026-09-11 09:45'),(14,15,'2026-09-29 08:45');

INSERT INTO Tracking_Event (shipment_id, hub_id, status, remarks, event_time) VALUES
(1,1,'Booked','Booking confirmed','2026-09-01 10:00'),(1,1,'Picked Up',NULL,'2026-09-02 09:00'),
(1,1,'Departed Hub',NULL,'2026-09-02 10:00'),(1,2,'Arrived at Hub',NULL,'2026-09-02 14:30'),
(1,2,'Out for Delivery',NULL,'2026-09-03 09:00'),(1,2,'Delivered','Signed by receiver','2026-09-03 12:15'),

(2,1,'Booked','Booking confirmed','2026-09-02 11:00'),(2,1,'Picked Up',NULL,'2026-09-03 08:00'),
(2,1,'Departed Hub',NULL,'2026-09-03 09:00'),(2,3,'Arrived at Hub','Delayed by road closure','2026-09-04 18:00'),
(2,3,'Out for Delivery',NULL,'2026-09-05 09:00'),(2,3,'Delivered','Signed by receiver','2026-09-05 11:30'),

(3,2,'Booked','Booking confirmed','2026-09-03 09:00'),(3,2,'Picked Up',NULL,'2026-09-04 08:00'),
(3,2,'Departed Hub',NULL,'2026-09-04 09:00'),(3,4,'Arrived at Hub',NULL,'2026-09-05 20:00'),
(3,4,'Out for Delivery',NULL,'2026-09-06 09:00'),(3,4,'Delivered','Signed by receiver','2026-09-06 13:00'),

(4,3,'Booked','Fragile item','2026-09-05 12:00'),(4,3,'Picked Up',NULL,'2026-09-06 07:00'),
(4,3,'Departed Hub',NULL,'2026-09-06 08:00'),(4,1,'Arrived at Hub',NULL,'2026-09-07 05:00'),
(4,1,'Out for Delivery',NULL,'2026-09-07 08:30'),(4,1,'Delivered','Handled with care','2026-09-07 11:00'),

(5,2,'Booked','Booking confirmed','2026-09-06 15:00'),(5,2,'Picked Up','Pickup delayed, no bike free','2026-09-11 08:00'),
(5,2,'Departed Hub',NULL,'2026-09-11 09:00'),(5,1,'Arrived at Hub',NULL,'2026-09-11 19:00'),
(5,1,'Out for Delivery',NULL,'2026-09-12 09:00'),(5,1,'Delivered','Signed by receiver','2026-09-12 10:45'),

(6,4,'Booked','Booking confirmed','2026-09-08 10:00'),(6,4,'Picked Up',NULL,'2026-09-09 07:00'),
(6,4,'Departed Hub',NULL,'2026-09-09 08:00'),(6,5,'Arrived at Hub',NULL,'2026-09-12 18:00'),
(6,5,'Out for Delivery',NULL,'2026-09-13 09:00'),(6,5,'Delivered','Signed by receiver','2026-09-13 11:30'),

(7,5,'Booked','Booking confirmed','2026-09-10 10:00'),(7,5,'Picked Up',NULL,'2026-09-11 09:00'),
(7,5,'Departed Hub',NULL,'2026-09-11 10:00'),(7,1,'Arrived at Hub',NULL,'2026-09-12 02:00'),
(7,1,'Out for Delivery',NULL,'2026-09-12 09:00'),(7,1,'Failed','Receiver not available','2026-09-12 14:00'),

(8,3,'Booked','Booking confirmed','2026-09-12 09:00'),(8,3,'Picked Up',NULL,'2026-09-14 08:00'),
(8,3,'Departed Hub',NULL,'2026-09-14 09:00'),(8,2,'Arrived at Hub',NULL,'2026-09-17 20:00'),
(8,2,'Out for Delivery',NULL,'2026-09-18 09:00'),(8,2,'Delivered','Signed by receiver','2026-09-18 12:00'),

(9,1,'Booked','Fragile item','2026-09-15 10:00'),(9,1,'Picked Up',NULL,'2026-09-16 08:00'),
(9,1,'Departed Hub',NULL,'2026-09-16 09:00'),(9,2,'Arrived at Hub','Transfer hub','2026-09-16 14:00'),
(9,2,'Departed Hub',NULL,'2026-09-17 06:00'),

(10,4,'Booked','Booking confirmed','2026-09-18 10:00'),(10,4,'Picked Up',NULL,'2026-09-19 08:00'),
(10,4,'Departed Hub',NULL,'2026-09-19 09:00'),

(11,3,'Booked','Booking confirmed','2026-09-20 10:00'),(11,3,'Picked Up',NULL,'2026-09-21 08:00'),
(11,3,'Departed Hub',NULL,'2026-09-21 09:00'),(11,5,'Arrived at Hub',NULL,'2026-09-24 18:00'),
(11,5,'Out for Delivery',NULL,'2026-09-25 09:00'),

(12,5,'Booked','Booking confirmed','2026-09-22 10:00'),
(13,1,'Booked','Booking confirmed','2026-09-25 10:00'),

(14,1,'Booked','Booking confirmed','2026-09-26 10:00'),(14,1,'Picked Up',NULL,'2026-09-27 08:00'),
(14,1,'Departed Hub',NULL,'2026-09-27 09:00'),(14,5,'Arrived at Hub',NULL,'2026-09-30 18:00'),
(14,5,'Out for Delivery',NULL,'2026-10-01 09:00'),(14,5,'Failed','Address incorrect','2026-10-01 13:00'),

(15,2,'Booked','Express booking','2026-09-28 10:00'),(15,2,'Picked Up',NULL,'2026-09-29 08:00'),
(15,2,'Departed Hub',NULL,'2026-09-29 09:00'),(15,1,'Arrived at Hub',NULL,'2026-09-29 15:00'),
(15,1,'Out for Delivery',NULL,'2026-09-30 09:00'),(15,1,'Delivered','Signed by receiver','2026-09-30 11:00');
