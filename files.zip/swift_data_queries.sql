-- =====================================================
-- Swift Data : Core queries
-- =====================================================
USE swift_data;

-- Q1. Full tracking history of one package
SELECT s.tracking_number, te.event_time, te.status, h.name AS hub, te.remarks
FROM Tracking_Event te
JOIN Shipment s ON s.shipment_id = te.shipment_id
LEFT JOIN Hub h ON h.hub_id = te.hub_id
WHERE s.tracking_number = 'TRK1002'
ORDER BY te.event_time;

-- Q2. Deliveries per driver per month (completed trips' delivered shipments)
SELECT d.name AS driver,
       DATE_FORMAT(s.delivered_date, '%Y-%m') AS month,
       COUNT(*) AS deliveries
FROM Driver d
JOIN Trip t           ON t.driver_id = d.driver_id
JOIN Trip_Shipment ts ON ts.trip_id = t.trip_id
JOIN Shipment s       ON s.shipment_id = ts.shipment_id
WHERE s.current_status = 'Delivered'
GROUP BY d.driver_id, d.name, month
ORDER BY month, deliveries DESC;

-- Q3. Late deliveries per destination hub
SELECT h.name AS hub,
       COUNT(*) AS total_delivered,
       SUM(DATE(s.delivered_date) > s.expected_date) AS late_deliveries,
       ROUND(100 * SUM(DATE(s.delivered_date) > s.expected_date) / COUNT(*), 1) AS late_percent
FROM Shipment s
JOIN Hub h ON h.hub_id = s.dest_hub_id
WHERE s.current_status = 'Delivered'
GROUP BY h.hub_id, h.name
ORDER BY late_deliveries DESC;

-- Q4. Vehicle utilization (current load vs capacity)
SELECT plate_no, type, status, current_load_kg, capacity_kg,
       ROUND(100 * current_load_kg / capacity_kg, 1) AS utilization_percent
FROM Vehicle
ORDER BY utilization_percent DESC;

-- Q5. Revenue by service type and by source city
SELECT service_type, COUNT(*) AS shipments, SUM(cost) AS revenue
FROM Shipment GROUP BY service_type;

SELECT h.city, COUNT(*) AS shipments, SUM(s.cost) AS revenue
FROM Shipment s JOIN Hub h ON h.hub_id = s.source_hub_id
GROUP BY h.city ORDER BY revenue DESC;

-- Q6. Customers (as senders) with the most failed deliveries
SELECT c.name, c.city, COUNT(*) AS failed_deliveries
FROM Shipment s JOIN Customer c ON c.customer_id = s.sender_id
WHERE s.current_status = 'Failed'
GROUP BY c.customer_id, c.name, c.city
ORDER BY failed_deliveries DESC;

-- Q7. Shipments that travelled on more than one trip (the M:N case)
SELECT s.tracking_number, COUNT(ts.trip_id) AS trips_used
FROM Shipment s JOIN Trip_Shipment ts ON ts.shipment_id = s.shipment_id
GROUP BY s.shipment_id, s.tracking_number
HAVING COUNT(ts.trip_id) > 1;
